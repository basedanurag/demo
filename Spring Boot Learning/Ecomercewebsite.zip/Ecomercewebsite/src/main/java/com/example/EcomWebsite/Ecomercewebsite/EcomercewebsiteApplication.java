package com.example.EcomWebsite.Ecomercewebsite;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EcomercewebsiteApplication {

	public static void main(String[] args) {
		SpringApplication.run(EcomercewebsiteApplication.class, args);
	}

}
