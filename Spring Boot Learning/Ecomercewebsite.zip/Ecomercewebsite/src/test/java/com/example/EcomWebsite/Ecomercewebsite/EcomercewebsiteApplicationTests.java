package com.example.EcomWebsite.Ecomercewebsite;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EcomercewebsiteApplicationTests {

	@Test
	void contextLoads() {
	}

}
